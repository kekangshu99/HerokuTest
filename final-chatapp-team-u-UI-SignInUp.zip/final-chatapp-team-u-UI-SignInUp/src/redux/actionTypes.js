 // user info
 export const SET_USER_TOKEN = "SET_USER_TOKEN";
 export const SET_USER_INFO = "SET_USER_INFO";
 export const MODIFY_USER_INFO = "MODIFY_USER_INFO";
 export const CLEAR_USER_INFO = "CLEAR_USER_INFO";

 // chat info
 export const GET_JOINED_ROOMS = 'GET_JOINED_ROOMS';
 export const CREATE_ROOM = 'CREATE_ROOM';
 export const JOIN_A_ROOM = 'JOIN_A_ROOM';
 export const DO_NOTHING = 'DO_NOTHING';

 export const GET_USERS_IN_ROOM = 'GET_USERS_IN_ROOM';


